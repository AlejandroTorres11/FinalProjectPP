
package Common;

import java.io.Serializable;

/**
 *
 * @author alejandro
 */
public record InfoAlmacen(int nGalletasAlmacenadas,int nGalletasConsumidas) implements Serializable {}
